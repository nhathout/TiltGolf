#ifndef GAMESCREEN_H
#define GAMESCREEN_H

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QTimer>

class IMUScreen; // forward declaration

class GameScreen : public QWidget {
	Q_OBJECT
public:
	GameScreen(QWidget *parent = nullptr);
	void setLevel(int newevelId);
signals:
	void exitToMenu();

private slots:
	void restartLevel();
	void updateTimer();
	void openIMUScreen();

private:
	int levelId;
	int timeElapsed;
	QVBoxLayout *mainLayout;
	QHBoxLayout *topBar;
	QLabel *levelLabel;
	QLabel *timerLabel;
	QPushButton *restartButton;
	QPushButton *exitButton;
	QPushButton *imuButton;
	QTimer *timer;
	IMUScreen *imuScreen = nullptr; // store pointer to current IMUScreen
};

#endif

